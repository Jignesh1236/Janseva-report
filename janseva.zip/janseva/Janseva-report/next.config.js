/** @type {import('next').NextConfig} */
const nextConfig = {
  // Next.js 14 uses app directory by default
}

module.exports = nextConfig